document.getElementById("menuBtn").onclick = function() {
    document.getElementById("sideNav").style.width = "250px";
}

document.getElementById("closeBtn").onclick = function() {
    document.getElementById("sideNav").style.width = "0";
}
